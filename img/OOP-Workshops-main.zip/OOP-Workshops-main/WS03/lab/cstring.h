#ifndef SDDS_CSTRING_H_
#define SDDS_CSTRING_H_
namespace sdds {
   void strnCpy(char* des, const char* src, int len);
}
#endif // !SDDS_CSTRING_H_



