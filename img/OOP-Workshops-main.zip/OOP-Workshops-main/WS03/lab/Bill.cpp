#include <iostream>
#include "cstring.h"
#include "Bill.h"
using namespace std;
namespace sdds {


}