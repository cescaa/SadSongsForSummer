#include "cstring.h"
namespace sdds {
  

}