#ifndef SDDS_CSTRING_H_
#define SDDS_CSTRING_H_
namespace sdds {
  

}
#endif // !SDDS_CSTRING_H_



